import os
import sys
import time
import json
import pytz
import requests
from datetime import datetime
from browser_automation import navigate_browser, run_javascript_browser, view_browser

# Beijing timezone for time checks
BEIJING_TZ = pytz.timezone('Asia/Shanghai')
BUSINESS_START_HOUR = 10  # 10:00 AM Beijing time
BUSINESS_END_HOUR = 22    # 10:00 PM Beijing time

def extract_data():
    """
    Extract data from the iWOD dashboard using browser commands
    Returns a dictionary containing the scraped data
    """
    try:
        # Navigate to the dashboard using Devin browser command
        navigate_browser('https://www.iwod.cn/admin/dataAnalysis/storeSummary?title=%E6%95%B0%E6%8D%AE%E6%A6%82%E5%86%B5')
        
        # Execute JavaScript to extract data using specific devinids
        js_script = """
        const metrics = {};
        metrics['线上销售额元'] = document.querySelector('p[devinid="54"]').textContent;
        metrics['线下销售额元'] = document.querySelector('p[devinid="59"]').textContent;
        metrics['结算金额元'] = document.querySelector('p[devinid="64"]').textContent;
        metrics['新增会员人'] = document.querySelector('p[devinid="69"]').textContent;
        metrics['新增潜客人'] = document.querySelector('p[devinid="74"]').textContent;
        metrics['售课节'] = document.querySelector('p[devinid="79"]').textContent;
        metrics['客流人次'] = document.querySelector('p[devinid="84"]').textContent;
        console.log(JSON.stringify(metrics, null, 2));
        metrics;
        """
        
        result = run_javascript_browser(js_script)
        
        # Parse the extracted data
        metrics = json.loads(result)
        data = {
            'timestamp': datetime.now(BEIJING_TZ).strftime('%Y-%m-%d %H:%M:%S'),
            'metrics': {
                '线上销售额': float(metrics.get('线上销售额元', 0)),
                '线下销售额': float(metrics.get('线下销售额元', 0)),
                '结算金额': float(metrics.get('结算金额元', 0)),
                '新增会员': int(metrics.get('新增会员人', 0)),
                '新增潜客': int(metrics.get('新增潜客人', 0)),
                '售课': int(metrics.get('售课节', 0)),
                '客流': int(metrics.get('客流人次', 0))
            }
        }
        return data
        
    except Exception as e:
        print(f"Error extracting data: {str(e)}")
        # Return default data structure with zeros
        return {
            'timestamp': datetime.now(BEIJING_TZ).strftime('%Y-%m-%d %H:%M:%S'),
            'metrics': {
                '线上销售额': 0,
                '线下销售额': 0,
                '结算金额': 0,
                '新增会员': 0,
                '新增潜客': 0,
                '售课': 0,
                '客流': 0
            }
        }

def send_data(data):
    """
    Send the extracted data via DingTalk webhook
    """
    webhook_url = "https://oapi.dingtalk.com/robot/send?access_token=421a362f9545cd2c065cfc5012fb192f93b158adee97de8667e1c254ac9c785f"
    
    # Format the message
    metrics = data['metrics']
    message = f"数据分享 - 健身房数据统计 ({data['timestamp']})\n\n"
    message += f"• 线上销售额: ¥{metrics['线上销售额']:.2f}\n"
    message += f"• 线下销售额: ¥{metrics['线下销售额']:.2f}\n"
    message += f"• 结算金额: ¥{metrics['结算金额']:.2f}\n"
    message += f"• 新增会员: {metrics['新增会员']}人\n"
    message += f"• 新增潜客: {metrics['新增潜客']}人\n"
    message += f"• 售课数量: {metrics['售课']}节\n"
    message += f"• 客流量: {metrics['客流']}人次\n"
    
    payload = {
        "msgtype": "text",
        "text": {
            "content": message
        }
    }
    
    try:
        response = requests.post(webhook_url, json=payload)
        response.raise_for_status()
        print(f"Data sent successfully to DingTalk at {datetime.now(BEIJING_TZ).strftime('%Y-%m-%d %H:%M:%S')}")
    except requests.exceptions.RequestException as e:
        print(f"Error sending data to DingTalk: {str(e)}")

def is_business_hours():
    """Check if current time is within Beijing business hours (10:00-22:00)"""
    beijing_time = datetime.now(BEIJING_TZ)
    return BUSINESS_START_HOUR <= beijing_time.hour < BUSINESS_END_HOUR

def job():
    """
    Main job to run hourly
    Only sends data during Beijing business hours (10:00-22:00)
    """
    try:
        if not is_business_hours():
            print(f"Outside of business hours (Beijing time: {datetime.now(BEIJING_TZ)})")
            return

        data = extract_data()
        send_data(data)
        print(f"Data extracted successfully at {datetime.now(BEIJING_TZ)}")
    except Exception as e:
        print(f"Error occurred: {str(e)}")

def main():
    """
    Main function to run the scraper once.
    Systemd service will handle scheduling.
    """
    try:
        job()
    except Exception as e:
        print(f"Critical error in main: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
